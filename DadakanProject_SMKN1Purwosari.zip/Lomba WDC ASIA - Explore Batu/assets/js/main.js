$(function()
{
    $('#tdestinasi').click(function()
    {
        $('body,html')
        .animate({scrollTop:220},1000)
    })
    
})
$(function()
{
    $('#tberita').click(function()
    {
        $('body,html')
        .animate({scrollTop:800},1000)
    })
    
})

$(function() {  $(window).scroll(function()
    {
        if($(this).scrollTop() > 675)
        {
            $("#tsection").slideDown();
        }
        else
        {
            $("#tsection").slideUp();
        }
    }) 
})

$(".loading").delay(3200).fadeOut(300) 